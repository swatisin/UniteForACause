DHTMLX JavaPlanner (v.1.0)

Description: 

DHMTLX JavaPlanner is a calendar control that allows creating rich-featured event and booking calendars for Java (incl. Spring, Struts, Grails Frameworks).
It is distributed under Commercial (JavaPlanner Standard) and Enterprise(JavaPlanner Pro) licenses. 
Free evalutation period is 30 days. To purchase DHTMLX JavaPlanner visit http://javaplanner.com/license.html/

(c) DHTMLX Ltd. 

Demo applications for Grails, Struts 2, Spring MVC and jsp are available here:
    http://javaplanner.com/download/demoapp_grails_trial.zip
    http://javaplanner.com/download/demoapp_spring_trial.war
    http://javaplanner.com/download/demoapp_struts_trial.war
    http://javaplanner.com/download/demoapp_jsp_trial.war

For more information refer to http://javaplanner.com/
